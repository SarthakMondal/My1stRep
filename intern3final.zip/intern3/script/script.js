//function to open the Navigation Menu
function navOpen()
{
    var nv = document.getElementsByClassName("navigationbar");
    var crs = document.getElementsByClassName("menubar");
    nv[0].style.marginLeft = "75%";
    nv[0].style.transition = "all 0.5s";
    console.log("navigationbar opened");

    const x = window.matchMedia("(max-width: 900px)");
    if(x.matches)
    {
        nv[0].style.marginLeft = "60%";
    }

    const y = window.matchMedia("(max-width: 480px)");
    if(y.matches)
    {
        nv[0].style.marginLeft = "45%";
    }
}

//function to close the Navigation Menu
function navClose()
{
    var nv = document.getElementsByClassName("navigationbar");
    nv[0].style.marginLeft = "120%";
    nv[0].style.transition = "all 0.5s";
    console.log("navigationbar closed");
}

//login form valiation

function validateLoginform()
{
    var a, b;
    a = document.getElementById("email").value;
    b = document.getElementById("pwd").value;

   
    if(a == "" && b == "")

    {
        document.getElementById("email").style.borderBottom = "solid 2px red";
        document.getElementById("pwd").style.borderBottom = "solid 2px red";
        document.getElementById("ermgs").innerHTML = "Please enter username and password to LogIN";
        return false;
    }

    else if(a == "")
    {
        document.getElementById("email").style.borderBottom = "solid 2px red";
        document.getElementById("ermgs").innerHTML = "Please enter Email Id to LogIN";
        return false;
    }

    else if(b == "")
    {
        document.getElementById("pwd").style.borderBottom = "solid 2px red";
        document.getElementById("ermgs").innerHTML = "Please enter Password to LogIN";
        return false;
    }

    

    else
    {
       
        return true;
    }

}


//sign up form validation

function validateSignup()
{
    console.log("checkSignup function called");
    var a,b,d,e,g,h;
    a = document.getElementById("fname").value;
    b = document.getElementById("email").value;
    d = document.getElementById("add").value;
    e = document.getElementById("pwd").value;
   
    g = e.length;
    h = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

    if (a != "" && b != "" && d != "" && e != "" )
    {

        if (b != "")
        {
           if (b.match(h))
           {
               
           }

           else
           {
                document.getElementById("ermgssign").innerHTML = "Enter a valid Email ID";
                document.getElementById("email").style.borderBottom = "solid 2px red";
                return false;
           }
        }



        if (g<5)
        {
            document.getElementById("ermgssign").innerHTML = "Password Must be 5 digits";
            document.getElementById("pwd").style.borderBottom = "solid 2px red";
            return false;
        }

        return true;


    }

    else
    {
        document.getElementById("ermgssign").innerHTML = "All Fields are mandatory";
        return false;
    }




}

//popup notification
function showAdded()
{
    window.alert("Product has been added to Cart... Check Now!")
}

//increasing counter
const counters = document.getElementsByClassName("countabout");
const s1 = 200;
var i, l = counters.length;


function updateCount()
{

    var countersQuantity = counters.length;
    var counter = [];
  
    for (i = 0; i < l; i++) {
      counter[i] = parseInt(counters[i].innerHTML);
    }
  
    var count = function(start, value, id) {
      var localStart = start;
      setInterval(function() {
        if (localStart < value) {
          localStart+=10;
          counters[id].innerHTML = localStart;
        }
      }, 4);
    }
  
    for (j = 0; j < l; j++) {
      count(0, counter[j], j);
    }
 
}


updateCount();


