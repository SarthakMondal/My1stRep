import cv2
import numpy as np
from matplotlib import pyplot as plt

t2 = np.arange(1, 500, 0.02)
t1 = np.arange(1, 500, 0.02)

fc = 1/10
x = np.cos(2*np.pi*fc*t2)

fm = 1/300
y = np.sin(2*np.pi*fm*t1)

z = np.multiply(y,x)

plt.subplot(311)
plt.plot(x)

plt.subplot(312)
plt.plot(y)

plt.subplot(313)
plt.plot(z)
plt.show()

plt.plot(x)
plt.plot(y)
plt.plot(z)

plt.show()

