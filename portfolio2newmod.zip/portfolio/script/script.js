//function to open the Navigation Menu
function navOpen()
{
    var nv = document.getElementsByClassName("navigationbar");
    var crs = document.getElementsByClassName("menubar");
    nv[0].style.marginLeft = "0";
    nv[0].style.transition = "all 0.5s";
    console.log("navigationbar opened");
}

//function to close the Navigation Menu
function navClose()
{
    var nv = document.getElementsByClassName("navigationbar");
    nv[0].style.marginLeft = "-65%"
    nv[0].style.transition = "all 0.5s";
    console.log("navigationbar closed");
}


const text = ["Hello viewer, pleasure to get you in my convertible portfolio Website. Explore the site to perceive more"];
let c = 0;
let index = 0;
let ct = "";
let l = "";

function typeWriter() 
{

   

    if(c === text.length)
    {
        c = 0;
    }

    ct = text[c];
    l = ct.slice(0, ++index);

    document.getElementById("typeEffect").textContent = l;
    if(l.length === ct.length)
    {
        c++;
        index = 0;
    }

    setTimeout(typeWriter, 150);
}

typeWriter();


var m, n, o, p, q, r, s, t, u;

function fullScreen1()
{
    m = document.getElementById("box1");
    n = document.getElementById("img1");
    o = document.getElementById("he1");
    m.style.cursor = "pointer";
    n.style.zIndex = "-1";
    o.style.opacity = "1";
    console.log("ok");
}

function halfScreen1()
{
    m = document.getElementById("box1");
    n = document.getElementById("img1");
    o = document.getElementById("he1");
    m.style.cursor = "";
    n.style.zIndex = "";
    o.style.opacity = "";
}

function fullScreen2()
{
    p = document.getElementById("box2");
    q = document.getElementById("img2");
    r = document.getElementById("he2");   
    p.style.cursor = "pointer";
    q.style.zIndex = "-1";
    r.style.opacity = "1";
}

function halfScreen2()
{
    p = document.getElementById("box2");
    q = document.getElementById("img2");
    r = document.getElementById("he2");
    p.style.cursor = "";
    q.style.zIndex = "";
    r.style.opacity = "";
}

function fullScreen3()
{
    s = document.getElementById("box3");
    t= document.getElementById("img3");
    u = document.getElementById("he3");

    s.style.cursor = "pointer";
    t.style.zIndex = "-1";
    u.style.opacity = "1";
}

function halfScreen3()
{
    s = document.getElementById("box3");
    t= document.getElementById("img3");
    u = document.getElementById("he3");
    s.style.cursor = "";
    t.style.zIndex = "";
    u.style.opacity = "";
}
