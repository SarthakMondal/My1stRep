function navOpen()
{
    var x = document.getElementsByClassName("navbar");
    var y = document.getElementsByTagName("li");
    var p = document.getElementsByClassName("contentindex");
    var i, z = y.length;
    x[0].style.height = "100vh";
    x[0].style.marginTop = "0";

    x[0].style.transition = "all 0.5s";
    x[0].style.opacity = "1";
    console.log("navigationmenu Opened");
    
   
}

function navClose()
{
    var x = document.getElementsByClassName("navbar");
    var y = document.getElementsByTagName("li");
    var p = document.getElementsByClassName("contentindex");
    var i, z = y.length;
    x[0].style.height = "50vh";
    x[0].style.marginTop = "-100%"
    p[0].style.zIndex = "1";
    x[0].style.transition = "all 0.5s";
    x[0].style.opacity = "0";
    console.log("navigationmenu closed");

}


const counters = document.getElementsByClassName("counterindex");
const s1 = 200;
var i, l = counters.length;


function updateCount()
{

    var countersQuantity = counters.length;
    var counter = [];
  
    for (i = 0; i < l; i++) {
      counter[i] = parseInt(counters[i].innerHTML);
    }
  
    var count = function(start, value, id) {
      var localStart = start;
      setInterval(function() {
        if (localStart < value) {
          localStart+=10;
          counters[id].innerHTML = localStart;
        }
      }, 4);
    }
  
    for (j = 0; j < l; j++) {
      count(0, counter[j], j);
    }
 
}


updateCount();


function validateLogin()
{
    var a, b;
    a = document.getElementById("email").value;
    b = document.getElementById("pwd").value;

   
    if(a == "" && b == "")

    {
        document.getElementById("email").style.border = "solid 2px red";
        document.getElementById("pwd").style.border = "solid 2px red";
        document.getElementById("ermgs").innerHTML = "Please enter username and password to LogIN";
        return false;
    }

    else if(a == "")
    {
        document.getElementById("email").style.border = "solid 2px red";
        document.getElementById("ermgs").innerHTML = "Please enter Email Id to LogIN";
        return false;
    }

    else if(b == "")
    {
        document.getElementById("pwd").style.border = "solid 2px red";
        document.getElementById("ermgs").innerHTML = "Please enter Password to LogIN";
        return false;
    }

    

    else
    {
       
        return true;
    }

}



function validateSignupform()
{

  console.log("checkSignup function called");
    var a,b,c,d,e,f,g,h;
    a = document.getElementById("fname").value;
    b = document.getElementById("email").value;
    c = document.getElementById("age").value;
    d = document.getElementById("ars").value;
    e = document.getElementById("pwd").value;
    f = document.getElementById("cpwd").value;
    g = e.length;
    h = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

    if (a != "" && b != "" && c != "" && d != "" && d != "" && e != "" && f != "")
    {

        if (b != "")
        {
           if (b.match(h))
           {
               
           }

           else
           {
                document.getElementById("ermgssign").innerHTML = "Enter a valid Email ID";
                document.getElementById("email").style.border = "solid 2px red";
                return false;
           }
        }


        if (c < 18 )
        {
            document.getElementById("ermgssign").innerHTML = "Must be an Adult";
            document.getElementById("age").style.border = "solid 2px red";
            return false;
        }

        if (g<6)
        {
            document.getElementById("ermgssign").innerHTML = "Password Must be 6 Digits";
            document.getElementById("pwd").style.border = "solid 2px red";
            return false;
        }

        if(e != f)
        {
            document.getElementById("ermgssign").innerHTML = "Password is not Confirmed";
            document.getElementById("pwd").style.border = "solid 2px red";
            document.getElementById("cpwd").style.border = "solid 2px red";
            return false;
            
        }

       

        return true;


    }

    else
    {
        document.getElementById("ermgssign").innerHTML = "All Fields are mandatory except Gender";
        return false;
    }



}