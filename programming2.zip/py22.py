import cv2
print("hello")
a = "C:\\Users\\sarth\\Downloads\\opencv-master\\data\\haarcascades\\haarcascade_frontalface_default.xml"
b = "C:\\Users\\sarth\\Downloads\\opencv-master\\data\\haarcascades\\haarcascade_eye_tree_eyeglasses.xml"
face_cascade = cv2.CascadeClassifier(a)
eye_cascade = cv2.CascadeClassifier(b)
print("hello2")
cap = cv2.VideoCapture(0)
print("hello3")
while cap.isOpened():
    print("hello4")
    _, img = cap.read()
    cv2.imshow('img', img)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(img, 1.1, 3)
    
    for (x, y , w ,h) in faces:
        cv2.rectangle(img, (x,y), (x+w, y+h), (255, 0 , 0), 3)
        roi_gray = gray[y:y+h, x:x+w]
        roi_color = img[y:y+h, x:x+w]
        eyes = eye_cascade.detectMultiScale(roi_gray)
        for (ex, ey ,ew, eh) in eyes:
            cv2.rectangle(roi_color, (ex,ey), (ex+ew, ey+eh), (0, 255, 0), 5)

    # Display the output
    cv2.imshow('img', img)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
