# -*- coding: utf-8 -*-
"""
Created on Sat Jan  4 18:51:23 2020

@author: sarth
"""

import cv2
import numpy as np

def main():
    
    w = 800
    h = 600
    
    
    cap = cv2.VideoCapture(0)
    
    cap.set(3, w)
    cap.set(4, h)
    
    print(cap.get(3))
    print(cap.get(4))
    
    if cap.isOpened():
        ret, frame = cap.read()
    else:
        ret = False

    ret, frame1 = cap.read()
    ret, frame2 = cap.read()


    while cap.isOpened():
        
        d = cv2.absdiff(frame1, frame2)
        #cv2.imshow("Original1", d)
        grey = cv2.cvtColor(d, cv2.COLOR_BGR2GRAY)
        #cv2.imshow("Original2", grey)
        blur = cv2.GaussianBlur(grey, (21, 21), 0)

        ret, thresh = cv2.threshold( blur, 20, 255, cv2.THRESH_BINARY)
        #cv2.imshow("Original4", thresh)
        thresht = cv2.dilate(thresh, None, iterations=2) #dilated = cv2.dilate(th, np.ones((3, 3), np.uint8), iterations=1 )
        #cv2.imshow("Original5", thresht)
        c,cnts = cv2.findContours(thresht.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        #cnts = imutils.grab_contours(cnts)
        #eroded = cv2.erode(dilated, np.ones((3, 3), np.uint8), iterations=1 )
        #cv2.imshow("Original6", cnts)
        #c, h = cv2.findContours(eroded, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
        #cv2.imshow("Original7", h)

        
	#frameDelta = cv2.absdiff(firstFrame, gray)
	#thresh = cv2.threshold(frameDelta, 25, 255, cv2.THRESH_BINARY)[1]
	
        
        m = cv2.drawContours(frame1, c, -1, (0,255,0), 2)
        #cv2.imshow("Original8", m)
        #cv2.imshow("frame2", frame2)
        cv2.imshow("Output", frame1)
        if cv2.waitKey(1) == 27: # exit on ESC
            break
        
        frame1 = frame2
        ret, frame2 = cap.read()

    cv2.destroyAllWindows()
    cap.release()

if __name__ == "__main__":
    main()
